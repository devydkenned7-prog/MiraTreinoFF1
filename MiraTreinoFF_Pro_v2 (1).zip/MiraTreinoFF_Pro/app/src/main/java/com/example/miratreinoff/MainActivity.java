package com.example.miratreinoff;
import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 LinearLayout root,arena; TextView stats; int hits,shots,streak,best; long start;
 public void onCreate(Bundle b){super.onCreate(b);build();}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setPadding(16,10,16,10);return v;}
 void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,25,20,15);
 root.addView(t("MIRA TREINO FF PRO",27));root.addView(t("Treine puxada, precisão e reação sem modificar o jogo.",15));
 stats=t("Precisão: 0%  |  Acertos: 0  |  Sequência: 0  |  Melhor: 0",17);root.addView(stats);
 LinearLayout bs=new LinearLayout(this);Button go=new Button(this);go.setText("INICIAR 30s");Button rz=new Button(this);rz.setText("ZERAR");bs.addView(go,new LinearLayout.LayoutParams(0,-2,1));bs.addView(rz,new LinearLayout.LayoutParams(0,-2,1));root.addView(bs);
 arena=new LinearLayout(this);arena.setGravity(Gravity.CENTER);arena.setBackgroundColor(Color.LTGRAY);root.addView(arena,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
 go.setOnClickListener(v->startRound());rz.setOnClickListener(v->{hits=shots=streak=best=0;update();arena.removeAllViews();});}
 void startRound(){hits=shots=streak=0;start=System.currentTimeMillis();spawn();new Handler().postDelayed(()->{arena.removeAllViews();update();Toast.makeText(this,"Treino encerrado!",Toast.LENGTH_SHORT).show();},30000);}
 void spawn(){if(System.currentTimeMillis()-start>=30000)return;arena.removeAllViews();TextView target=t("◎",58);target.setGravity(Gravity.CENTER);GradientDrawable bg=new GradientDrawable();bg.setShape(GradientDrawable.OVAL);bg.setColor(Color.WHITE);target.setBackground(bg);
 FrameLayout f=new FrameLayout(this);int size=150;f.addView(target,new FrameLayout.LayoutParams(size,size));target.setX((float)(Math.random()*250));target.setY((float)(Math.random()*500));
 target.setOnClickListener(v->{hits++;shots++;streak++;best=Math.max(best,streak);update();spawn();});arena.addView(f,new LinearLayout.LayoutParams(-1,-1));shots++;update();}
 void update(){int a=shots==0?0:hits*100/shots;stats.setText("Precisão: "+a+"%  |  Acertos: "+hits+"  |  Sequência: "+streak+"  |  Melhor: "+best);}
}